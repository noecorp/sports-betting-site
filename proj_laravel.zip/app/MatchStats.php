<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MatchStats extends Model
{
    protected $table = 'matchs';

    public $timestamps= false;
}
