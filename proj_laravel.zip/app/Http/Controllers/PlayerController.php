<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Player;
use Illuminate\Support\Facades\DB;

class PlayerController extends Controller
{
    public function index()
    {
        $players = DB::table('players')
        ->join('teams','players.team_id', '=', 'teams.id')
        ->select('players.Pname', 'teams.name','players.id')
        ->get();
        //var_dump($players);
      return view('player',compact('players'));
    }
}
