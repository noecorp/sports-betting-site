<?php

namespace App\Http\Controllers;

use App\TeamsStats;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class TeamsStatsController extends Controller
{
    public function display($team_id) {
        $teamStats = DB::table('statistics')->where('team_id', $team_id)->first();
        return view('teamstats', compact('teamStats'));
    }
}
