<?php

namespace App\Http\Controllers;

use App\Match;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class MatchController extends Controller
{
    public function index()
    {
        //$match = Match::all();
        $match = DB::table('matchs')
        ->join('teams as T','matchs.Team_1', '=', 'T.id')    
        ->join('teams as T2','matchs.Team_2', '=', 'T2.id')
        ->select('matchs.ScoreBoard','matchs.Placement','matchs.Winner','matchs.Team_1','matchs.Team_2','T.name as name1','T2.name as name2')
        ->get();
        // var_dump($match);
        //  exit();
        return view('Match.index',compact('match'));
    }
    
    
    public function display($id) {
        $match = DB::table('matchs')->where('id', $id)->first();
        return view('Match.display', compact('match'));
    }
}